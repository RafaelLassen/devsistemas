# I 💙 MB

[Sobre o projeto](/introduao)

Este documento de visão fornece uma visão geral do projeto Maise Brilliance. Ele descreve a finalidade, os principais stakeholders, os requisitos principais, os diagramas de caso de uso, diagrama de classes e protótipos de possíveis telas para o sistema. Este documento servirá como base para o desenvolvimento do projeto, auxiliando na compreensão e alinhamento das partes interessadas.S
O Maisie tem como objetivo te ajudar a escolher a joia que foi feita para VOCÊ combinando sembre com o seu guarda roupa.
Esperamos que tenha uma boa experiência e boas ideias através do projeto!

## DRIVE

Neste, você irá encontrar o Canvas do projeto, o Protótipo do site e os Diagramas

- [DRIVE](https://drive.google.com/drive/folders/1LGUQdN-HjwjJ_GKM3GvoyReRxR_jMyuQ?usp=drive_link)

O acesso está liberado para todos!
